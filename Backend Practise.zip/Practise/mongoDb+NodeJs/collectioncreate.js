//DB Creation
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/Mydemodb";

MongoClient.connect(url, function (err, db){
    if (err)
        throw err;
    var dbname = db.db("Mydemodb");
    var data = [
        { name: "Malar", city: "Mdu" },
        { name: "MalarMalar", city: "Mdu" },
        { name: "MalarMarees", city: "Mdu" }
    ];
//create collection
//dbname.createCollection("Students", function (err, result) {
// dbname.collection("Students").insertOne({ name: "Malar", city: "Mdu" }, function (err, result) {

    dbname.collection("Students").insertMany(data, function (err, result) {
    if (err) throw err;
    console.log("Doc's Insert Created");
    db.close();
    });

});


