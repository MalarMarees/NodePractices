var express = require('express');
var app = express();
var routing= require('./routing');
app.use('/' , routing);
app.listen(8080);
