var express= require('express');
var app= express();
var alert= require('alert');

app.use(function(req,res,next){
    alert("Welcome");
    console.log('Request',res.method,'and' ,req.url,'url address is running');
    next();
});

app.get('/' , function(req,res,next){
    console.log("First Page");
    res.send('Osiz');
    next();
});

app.get('/exit' , function(req,res,next){
    console.log("Second Page");
    res.send('Osiz_Tech');
    next();
});

app.use(function(req,res,next){
    alert("Denied");
    console.log('The End');
    next();
});

app.listen(8080);