var express = require('express');
var app = express();
var bodyParser= require('body-parser');
var urlencodedParser = bodyParser.urlencoded({extended: false})
//Get method
app.get('/', function (req, res) {
    res.sendFile(_dirname + '/' + "index.html");
});


// app.get('/home', function (req, res) {
//    res.send('<h1>Welcome '+req.query['username']+ '</h1> <br> <h2> Mail id :'+req.query['mailid']+'</h2>')
// });



// app.post('/home', function (req, res) {
//     res.send('<h1>Welcome '+req.query['username']+ '</h1> <br> <h2> Mail id :'+req.query['mailid']+'</h2>')
//  });

app.post('/home', urlencodedParser,function (req, res) {
    res.send('<h1>Welcome '+req.body.username+ '</h1> <br> <h2> Mail id :'+req.body.mailid +'</h2>')
 });
 app.listen(8080);